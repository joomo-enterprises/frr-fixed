// SPDX-License-Identifier: GPL-2.0-or-later
/* BGP attributes.
 * Copyright (C) 1996, 97, 98 Kunihiro Ishiguro
 */

#ifndef _QUAGGA_BGP_ATTR_H
#define _QUAGGA_BGP_ATTR_H

#include "mpls.h"
#include "typesafe.h"
#include "bgp_attr_evpn.h"
#include "bgpd/bgp_encap_types.h"
#include "bgpd/bgp_attr_srv6.h"
#include "srte.h"

/* Simple bit mapping. */
#define BITMAP_NBBY 8

#define SET_BITMAP(MAP, NUM)                                                   \
	SET_FLAG(MAP[(NUM) / BITMAP_NBBY], 1 << ((NUM) % BITMAP_NBBY))

#define CHECK_BITMAP(MAP, NUM)                                                 \
	CHECK_FLAG(MAP[(NUM) / BITMAP_NBBY], 1 << ((NUM) % BITMAP_NBBY))

#define BGP_MED_MAX UINT32_MAX

/* BGP Attribute type range. */
#define BGP_ATTR_TYPE_RANGE     256
#define BGP_ATTR_BITMAP_SIZE    (BGP_ATTR_TYPE_RANGE / BITMAP_NBBY)

/* BGP Attribute flags. */
#define BGP_ATTR_FLAG_OPTIONAL  0x80	/* Attribute is optional. */
#define BGP_ATTR_FLAG_TRANS     0x40	/* Attribute is transitive. */
#define BGP_ATTR_FLAG_PARTIAL   0x20	/* Attribute is partial. */
#define BGP_ATTR_FLAG_EXTLEN    0x10	/* Extended length flag. */

/* BGP attribute header must bigger than 2. */
#define BGP_ATTR_MIN_LEN        3       /* Attribute flag, type length. */
#define BGP_ATTR_DEFAULT_WEIGHT 32768

/* Valid lengths for mp_nexthop_len */
#define BGP_ATTR_NHLEN_IPV4               IPV4_MAX_BYTELEN
#define BGP_ATTR_NHLEN_VPNV4              (8 + IPV4_MAX_BYTELEN)
#define BGP_ATTR_NHLEN_IPV6_GLOBAL        IPV6_MAX_BYTELEN
#define BGP_ATTR_NHLEN_IPV6_GLOBAL_AND_LL (IPV6_MAX_BYTELEN * 2)
#define BGP_ATTR_NHLEN_VPNV6_GLOBAL       (8 + IPV6_MAX_BYTELEN)
#define BGP_ATTR_NHLEN_VPNV6_GLOBAL_AND_LL ((8+IPV6_MAX_BYTELEN) * 2)

/* Prefix SID types */
#define BGP_PREFIX_SID_LABEL_INDEX     1
#define BGP_PREFIX_SID_IPV6            2
#define BGP_PREFIX_SID_ORIGINATOR_SRGB 3
#define BGP_PREFIX_SID_VPN_SID 4
#define BGP_PREFIX_SID_SRV6_L3_SERVICE 5
#define BGP_PREFIX_SID_SRV6_L2_SERVICE 6

#define BGP_PREFIX_SID_LABEL_INDEX_LENGTH      7
#define BGP_PREFIX_SID_IPV6_LENGTH            19
#define BGP_PREFIX_SID_ORIGINATOR_SRGB_LENGTH  6
#define BGP_PREFIX_SID_VPN_SID_LENGTH         19

/* SRv6 Service Sub-TLV types */
#define BGP_PREFIX_SID_SRV6_SERVICE_SID_INFO		 1
#define BGP_PREFIX_SID_SRV6_SERVICE_SID_INFO_LENGTH	 21
#define BGP_PREFIX_SID_SRV6_SERVICE_SID_FLAGS_KNOWN_MASK 0x00

/* SRv6 Service Data Sub-Sub-TLV types */
#define BGP_PREFIX_SID_SRV6_SERVICE_SID_STRUCTURE	 1
#define BGP_PREFIX_SID_SRV6_SERVICE_SID_STRUCTURE_LENGTH 6

#define BGP_ATTR_NH_AFI(afi, attr) \
	((afi != AFI_L2VPN) ? afi : \
	((attr->mp_nexthop_len == BGP_ATTR_NHLEN_IPV4) ? AFI_IP : AFI_IP6))

/* PMSI tunnel types (RFC 6514) */

struct bgp_attr_encap_subtlv {
	struct bgp_attr_encap_subtlv *next; /* for chaining */
	/* Reference count of this attribute. */
	unsigned long refcnt;
	uint16_t type;
	uint16_t length;
	uint8_t value[0]; /* will be extended */
};

#ifdef ENABLE_BGP_VNC
/*
 * old rfp<->rfapi representation
 */
struct bgp_tea_options {
	struct bgp_tea_options *next;
	uint8_t options_count;
	uint16_t options_length; /* each TLV may be 256 in length */
	uint8_t type;
	uint8_t length;
	void *value; /* pointer to data */
};

#endif

enum pta_type {
	PMSI_TNLTYPE_NO_INFO = 0,
	PMSI_TNLTYPE_RSVP_TE_P2MP,
	PMSI_TNLTYPE_MLDP_P2MP,
	PMSI_TNLTYPE_PIM_SSM,
	PMSI_TNLTYPE_PIM_SM,
	PMSI_TNLTYPE_PIM_BIDIR,
	PMSI_TNLTYPE_INGR_REPL,
	PMSI_TNLTYPE_MLDP_MP2MP,
	PMSI_TNLTYPE_MAX = PMSI_TNLTYPE_MLDP_MP2MP
};

/* Hard limit on sub-TLVs within a single Tunnel Encap attribute (RFC 9012).
 * Prevents a peer from driving unbounded XCALLOC churn with valid packets.
 * This is not defined in the RFC, but is a sanity check to prevent memory
 * exhaustion.
 * Adding 64, just as a sanity number (I doubt more than 64 TLVs is a valid
 * case in real life...).
 */
#define BGP_ENCAP_SUBTLV_MAX 64

/* PMSI lengths for label-only, ipv4, and ipv6 "identifier" */
#define BGP_ATTR_PMSI_TUNNEL_LBL_ONLY_LEN 5
#define BGP_ATTR_PMSI_TUNNEL_V4_LENGTH    9
#define BGP_ATTR_PMSI_TUNNEL_V6_LENGTH    21

/*
 * Prefix-SID type-4
 * SRv6-VPN-SID-TLV
 * draft-dawra-idr-srv6-vpn-04
 */
struct bgp_attr_srv6_vpn {
	unsigned long refcnt;
	uint8_t sid_flags;
	struct in6_addr sid;
};

struct attr_extra {
	unsigned long refcnt;

	/* draft-ietf-idr-nhc attribute */
	struct bgp_nhc *nhc;

	/* EVPN overlay index */
	struct bgp_route_evpn *evpn_overlay;

	/* ES info */
	uint8_t es_flags;
	/* Path is not "locally-active" on the advertising VTEP. This is
	 * translated into an ARP-ND ECOM.
	 */
#define ATTR_ES_PROXY_ADVERT (1 << 0)
	/* Destination ES is present locally. This flag is set on local
	 * paths and sync paths
	 */
#define ATTR_ES_IS_LOCAL (1 << 1)
	/* There are one or more non-best paths from ES peers. Note that
	 * this flag is only set on the local MAC-IP paths in the VNI
	 * route table (not set in the global routing table). And only
	 * non-proxy advertisements from an ES peer can result in this
	 * flag being set.
	 */
#define ATTR_ES_PEER_ACTIVE (1 << 2)
	/* There are one or more non-best proxy paths from ES peers */
#define ATTR_ES_PEER_PROXY (1 << 3)
	/* An ES peer has router bit set - only applicable if
	 * ATTR_ES_PEER_ACTIVE is set
	 */
#define ATTR_ES_PEER_ROUTER (1 << 4)

	/* These two flags are only set on L3 routes installed in a
	 * VRF as a result of EVPN MAC-IP route
	 * XXX - while splitting up per-family attrs these need to be
	 * classified as non-EVPN
	 */
#define ATTR_ES_L3_NHG_USE    (1 << 5)
#define ATTR_ES_L3_NHG_ACTIVE (1 << 6)
#define ATTR_ES_L3_NHG	      (ATTR_ES_L3_NHG_USE | ATTR_ES_L3_NHG_ACTIVE)

	uint8_t df_alg;

	/* EVPN flags */
	uint8_t evpn_flags;
#define ATTR_EVPN_FLAG_STICKY	  (1 << 0)
#define ATTR_EVPN_FLAG_DEFAULT_GW (1 << 1)
/* NA router flag (R-bit) support in EVPN */
#define ATTR_EVPN_FLAG_ROUTER (1 << 2)

	/* EVPN DF preference for DF election on local ESs */
	uint16_t df_pref;

	/* EVPN MAC Mobility sequence number, if any. */
	uint32_t mm_seqnum;
	/* highest MM sequence number rxed in a MAC-IP route from an
	 * ES peer (this includes both proxy and non-proxy MAC-IP
	 * advertisements from ES peers).
	 * This is only applicable to local paths in the VNI routing
	 * table and derived from other imported/non-best paths.
	 */
	uint32_t mm_sync_seqnum;

	/* EVPN local router-mac */
	struct ethaddr rmac;

	/* EVPN ES */
	esi_t esi;

	/* AIGP TLVs */
	struct bgp_aigp_tlvs *aigp_tlvs;

	/* For BGP-LS Attribute (RFC 9552) */
	struct bgp_ls_attr *ls_attr;

	/* SRv6 VPN SID */
	struct bgp_attr_srv6_vpn *srv6_vpn;

	/* SRv6 L2 service SID */
	struct bgp_attr_srv6_service *srv6_l2service;

	/* SRv6 L3 service SID */
	struct bgp_attr_srv6_service *srv6_l3service;

	/* PMSI tunnel type (RFC 6514). */
	enum pta_type pmsi_tnl_type;

	/* PMSI Tunnel Id */
	struct in6_addr tunn_id;

	/* RFC 9234 */
	uint32_t otc;

	/* Attributes received with the Partial bit set (RFC 4271 section 5). */
	uint64_t partial_attrs;

	/* IPv6 Extended Communities attribute. */
	struct ecommunity *ipv6_ecommunity;
};

extern struct attr_extra *bgp_attr_extra_get(struct attr *attr);
extern void bgp_attr_extra_put(struct attr *attr);
extern struct attr_extra *bgp_attr_extra_dup(const struct attr_extra *src);
extern void bgp_attr_extra_discard(struct attr *attr);
extern void bgp_attr_dup_into(struct attr *to, const struct attr *from);

/* BGP core attribute structure. */
struct attr {
	/* AS Path structure */
	struct aspath *aspath;

	/* Community structure */
	struct community *community;

	/* Reference count of this attribute. */
	unsigned long refcnt;

	/* Flag of attribute is set or not. */
	uint64_t flag;

	/* Apart from in6_addr, the remaining static attributes */
	struct in_addr nexthop;
	uint32_t med;
	uint32_t local_pref;
	ifindex_t nh_ifindex;
	uint8_t nh_flags;

#define BGP_ATTR_NH_VALID 0x01
#define BGP_ATTR_NH_IF_OPERSTATE 0x02
#define BGP_ATTR_NH_MP_PREFER_GLOBAL 0x04 /* MP Nexthop preference */

	/* Path origin attribute */
	uint8_t origin;

	/* Distance as applied by Route map */
	uint8_t distance;

	/* has the route-map changed any attribute?
	   Used on the peer outbound side. */
	uint16_t rmap_change_flags;

	/* Cache to avoid repeated interning within a single UPDATE section */
	struct {
		bool valid;

		/* interned attr(reference) to reuse during prefix parsing */
		struct attr *interned;

		/* parsed attr pointer for equality check */
		struct attr *parsed_attr;
	} attr_intern_reuse;

	/* MP Nexthop length */
	uint8_t mp_nexthop_len;

	uint16_t encap_tunneltype;

	/* Multi-Protocol Nexthop, AFI IPv6 */
	struct in6_addr mp_nexthop_global;
	struct in6_addr mp_nexthop_local;

	/* ifIndex corresponding to mp_nexthop_local. */
	ifindex_t nh_lla_ifindex;

	/* MPLS label */
	mpls_label_t label;

	/* Extended Communities attribute. */
	struct ecommunity *ecommunity;

	/* Large Communities attribute. */
	struct lcommunity *lcommunity;

	/* Route-Reflector Cluster attribute */
	struct cluster_list *cluster1;

	/* Unknown transitive attribute. */
	struct transit *transit;

	struct in_addr mp_nexthop_global_in;

	/* Aggregator Router ID attribute */
	struct in_addr aggregator_addr;

	/* Route Reflector Originator attribute */
	struct in_addr originator_id;

	/* Local weight, not actually an attribute */
	uint32_t weight;

	/* Aggregator ASN */
	as_t aggregator_as;

	/* route tag */
	route_tag_t tag;

	/* Label index */
	uint32_t label_index;

	/* rmap set table */
	uint32_t rmap_table_id;

	struct bgp_attr_encap_subtlv *encap_subtlvs; /* rfc5512 */

#ifdef ENABLE_BGP_VNC
	struct bgp_attr_encap_subtlv *vnc_subtlvs; /* VNC-specific */
#endif

	/* Nexthop type */
	enum nexthop_types_t nh_type;

	/* If NEXTHOP_TYPE_BLACKHOLE, then blackhole type */
	enum blackhole_type bh_type;

	/* Optional feature-specific attributes */
	struct attr_extra *extra;
};

/* rmap_change_flags definition */
#define BATTR_RMAP_IPV4_NHOP_CHANGED (1 << 0)
#define BATTR_RMAP_NEXTHOP_PEER_ADDRESS (1 << 1)
#define BATTR_RMAP_NEXTHOP_UNCHANGED (1 << 3)
#define BATTR_RMAP_IPV6_GLOBAL_NHOP_CHANGED (1 << 4)
#define BATTR_RMAP_IPV6_LL_NHOP_CHANGED (1 << 5)
#define BATTR_RMAP_IPV6_PREFER_GLOBAL_CHANGED (1 << 6)
#define BATTR_RMAP_LINK_BW_SET (1 << 7)
#define BATTR_RMAP_L3VPN_ACCEPT_GRE (1 << 8)
#define BATTR_RMAP_VPNV4_NHOP_CHANGED (1 << 9)
#define BATTR_RMAP_VPNV6_GLOBAL_NHOP_CHANGED (1 << 10)
#define BATTR_RMAP_L3VPN_ACCEPT_GRETAP	      (1 << 11)

/* Router Reflector related structure. */
struct cluster_list {
	unsigned long refcnt;
	int length;
	struct in_addr *list;
};

/* AIGP TLVs (RFC 7311 section 3). Only the first one (metric[0]) is used,
 * the others are passed along unchanged.
 */
PREDECL_HASH(bgp_aigp_tlvs_hash);

struct bgp_aigp_tlvs {
	struct bgp_aigp_tlvs_hash_item item;
	unsigned long refcnt;
	uint16_t count;
	uint64_t metric[];
};

/* Unknown transit attribute. */
struct transit {
	unsigned long refcnt;
	int length;
	uint8_t *val;
};

/* "(void) 0" will generate a compiler error.  this is a safety check to
 * ensure we're not using a value that exceeds the bit size of attr->flag. */
#define ATTR_FLAG_BIT(X)                                                       \
	__builtin_choose_expr((X) >= 1 && (X) <= 64, 1ULL << ((X)-1), (void)0)

#define bgp_attr_exists(attr, id) CHECK_FLAG((attr)->flag, ATTR_FLAG_BIT(id))
#define bgp_attr_set(attr, id) SET_FLAG((attr)->flag, ATTR_FLAG_BIT(id))
#define bgp_attr_unset(attr, id) UNSET_FLAG((attr)->flag, ATTR_FLAG_BIT(id))

#define BGP_CLUSTER_LIST_LENGTH(attr)                                                             \
	(bgp_attr_exists(attr, BGP_ATTR_CLUSTER_LIST) ? bgp_attr_get_cluster((attr))->length : 0)

enum bgp_attr_parse_ret {
	BGP_ATTR_PARSE_PROCEED = 0,
	BGP_ATTR_PARSE_ERROR = -1,
	BGP_ATTR_PARSE_WITHDRAW = -2,
	/* Treat as withdraw, but do not complain in the logs.
	 * This is used in bgp_attr_ignore() when we want to
	 * withdraw the paths having the specified attribute.
	 */
	BGP_ATTR_PARSE_WITHDRAW_IGNORE = -3,

	/* only used internally, send notify + convert to BGP_ATTR_PARSE_ERROR
	 */
	BGP_ATTR_PARSE_ERROR_NOTIFYPLS = -4,
	BGP_ATTR_PARSE_MISSING_MANDATORY = -5,
};

struct bpacket_attr_vec_arr;

/* Prototypes. */
extern void bgp_attr_init(void);
extern void bgp_attr_finish(void);
extern enum bgp_attr_parse_ret bgp_attr_parse(struct peer_connection *connection, struct attr *attr,
					      bgp_size_t size, struct bgp_nlri *mp_update,
					      struct bgp_nlri *mp_withdraw, bool has_nlri);
extern struct attr *bgp_attr_intern(struct attr *attr);
extern struct bgp_attr_srv6_service *
bgp_attr_srv6_l2service_intern(struct bgp_attr_srv6_service *l2service);
extern struct bgp_attr_srv6_service *
bgp_attr_srv6_l3service_intern(struct bgp_attr_srv6_service *l3service);
extern void bgp_attr_srv6_service_free(struct bgp_attr_srv6_service *service);
extern void bgp_attr_unintern_sub(struct attr *attr);
extern void bgp_attr_unintern(struct attr **pattr);
extern void bgp_attr_flush(struct attr *attr);
extern void bgp_attr_unintern_clear_reuse(struct attr *parsed_attr, struct attr **p);
extern struct attr *bgp_attr_default_set(struct attr *attr, struct bgp *bgp,
					 uint8_t origin);
extern struct attr *bgp_attr_aggregate_intern(
	struct bgp *bgp, uint8_t origin, struct aspath *aspath,
	struct community *community, struct ecommunity *ecommunity,
	struct lcommunity *lcommunity, struct bgp_aggregate *aggregate,
	uint8_t atomic_aggregate, const struct prefix *p);
extern void bgp_peer_prepend_local_as(struct peer *peer, afi_t afi, safi_t safi, struct attr *attr);
extern bgp_size_t
bgp_packet_attribute(struct bgp *bgp, struct peer *peer, struct stream *s, struct attr *attr,
		     struct bpacket_attr_vec_arr *vecarr, struct prefix *p, afi_t afi, safi_t safi,
		     struct peer *from, struct prefix_rd *prd, mpls_label_t *label,
		     uint8_t num_labels, struct bgp_attr_srv6_service *srv6_unicast,
		     bool addpath_capable, uint32_t addpath_tx_id, struct bgp_path_info *bpi,
		     struct bgp_ls_nlri *ls_nlri, bool for_bmp);
extern void bgp_dump_routes_attr(struct stream *s, struct bgp_path_info *bpi,
				 const struct prefix *p);
extern bool attrhash_cmp(const void *arg1, const void *arg2);
extern unsigned int attrhash_key_make(const void *p);
extern void attr_show_all(struct vty *vty, bool summary);
extern unsigned long int attr_count(void);
extern unsigned long int attr_unknown_count(void);
extern void bgp_path_attribute_discard_vty(struct vty *vty, struct peer *peer,
					   const char *discard_attrs, bool set);
extern void bgp_path_attribute_withdraw_vty(struct vty *vty, struct peer *peer,
					    const char *withdraw_attrs,
					    bool set);
extern enum bgp_attr_parse_ret bgp_attr_ignore(struct peer *peer, uint8_t type);

/* Cluster list prototypes. */
extern bool cluster_loop_check(struct cluster_list *cluster,
			       struct in_addr originator);
extern void bgp_attr_prepend_cluster_id(struct bgp *bgp, struct attr *attr);
extern void bgp_attr_clear_reflection(struct attr *attr);
extern void bgp_attr_strip_unsent_communities(struct peer *peer, afi_t afi, safi_t safi,
					      struct attr *attr);

/* Below exported for unit-test purposes only */
struct bgp_attr_parser_args {
	struct peer_connection *connection;
	bgp_size_t length; /* attribute data length; */
	bgp_size_t total;  /* total length, inc header */
	struct attr *attr;
	uint8_t type;
	uint8_t flags;
	uint8_t *startp;
};
extern int bgp_mp_reach_parse(struct bgp_attr_parser_args *args,
			      struct bgp_nlri *mp_update);
extern int bgp_mp_unreach_parse(struct bgp_attr_parser_args *args,
				struct bgp_nlri *mp_withdraw);
extern enum bgp_attr_parse_ret
bgp_attr_prefix_sid(struct bgp_attr_parser_args *args);

extern struct bgp_attr_encap_subtlv *
encap_tlv_dup(struct bgp_attr_encap_subtlv *orig);

extern void bgp_attr_flush_encap(struct attr *attr);

extern void bgp_attr_extcom_tunnel_type(struct attr *attr,
					 bgp_encap_types *tunnel_type);

/**
 * Set of functions to encode MP_REACH_NLRI and MP_UNREACH_NLRI attributes.
 * Typical call sequence is to call _start(), followed by multiple _prefix(),
 * one for each NLRI that needs to be encoded into the UPDATE message, and
 * finally the _end() function.
 */
extern size_t bgp_packet_mpattr_start(struct stream *s, struct peer *peer,
				      afi_t afi, safi_t safi,
				      struct bpacket_attr_vec_arr *vecarr,
				      struct attr *attr);
extern void bgp_packet_mpattr_prefix(struct stream *s, afi_t afi, safi_t safi,
				     const struct prefix *p, const struct prefix_rd *prd,
				     mpls_label_t *label, uint8_t num_labels, bool addpath_capable,
				     uint32_t addpath_tx_id, struct attr *attr,
				     struct bgp_ls_nlri *ls_nlri,
				     struct bgp_path_info *path);
extern size_t bgp_packet_mpattr_prefix_size(afi_t afi, safi_t safi,
					    const struct prefix *p);
extern void bgp_packet_mpattr_end(struct stream *s, size_t sizep);

extern size_t bgp_packet_mpunreach_start(struct stream *s, afi_t afi,
					 safi_t safi);
extern void bgp_packet_mpunreach_prefix(struct stream *s, const struct prefix *p, afi_t afi,
					safi_t safi, const struct prefix_rd *prd,
					mpls_label_t *label, uint8_t num_labels,
					bool addpath_capable, uint32_t addpath_tx_id,
					struct attr *attr, struct bgp_ls_nlri *ls_nlri);
extern void bgp_packet_mpunreach_end(struct stream *s, size_t attrlen_pnt);

extern enum bgp_attr_parse_ret bgp_attr_nexthop_valid(struct peer *peer,
						      struct attr *attr);

static inline bool bgp_rmap_nhop_changed(uint32_t out_rmap_flags)
{
	return ((CHECK_FLAG(out_rmap_flags, BATTR_RMAP_NEXTHOP_PEER_ADDRESS) ||
		 CHECK_FLAG(out_rmap_flags, BATTR_RMAP_NEXTHOP_UNCHANGED) ||
		 CHECK_FLAG(out_rmap_flags, BATTR_RMAP_IPV4_NHOP_CHANGED) ||
		 CHECK_FLAG(out_rmap_flags, BATTR_RMAP_VPNV4_NHOP_CHANGED) ||
		 CHECK_FLAG(out_rmap_flags, BATTR_RMAP_VPNV6_GLOBAL_NHOP_CHANGED) ||
		 CHECK_FLAG(out_rmap_flags, BATTR_RMAP_IPV6_GLOBAL_NHOP_CHANGED) ||
		 CHECK_FLAG(out_rmap_flags, BATTR_RMAP_IPV6_PREFER_GLOBAL_CHANGED) ||
		 CHECK_FLAG(out_rmap_flags, BATTR_RMAP_IPV6_LL_NHOP_CHANGED))
			? true
			: false);
}

static inline enum pta_type bgp_attr_get_pmsi_tnl_type(const struct attr *attr)
{
	return attr->extra ? attr->extra->pmsi_tnl_type : PMSI_TNLTYPE_NO_INFO;
}

static inline void bgp_attr_unset_tunn_id(struct attr *attr)
{
	if (!attr->extra || bgp_attr_get_pmsi_tnl_type(attr) != PMSI_TNLTYPE_INGR_REPL)
		return;

	attr->extra->tunn_id = in6addr_any;
}

/* One attr_extra slot covers both pmsi_tnl_type and (for INGR_REPL) tunn_id. */
static inline void bgp_attr_set_pmsi_tnl_type(struct attr *attr,
					      enum pta_type pmsi_tnl_type)
{
	enum pta_type old = bgp_attr_get_pmsi_tnl_type(attr);

	if (old == pmsi_tnl_type)
		return;

	/* Zero tunn_id when leaving INGR_REPL (no refcnt change). */
	if (old == PMSI_TNLTYPE_INGR_REPL && pmsi_tnl_type != PMSI_TNLTYPE_INGR_REPL)
		bgp_attr_unset_tunn_id(attr);

	if (pmsi_tnl_type == PMSI_TNLTYPE_NO_INFO) {
		/* Release slot (old was non-NO_INFO). */
		attr->extra->pmsi_tnl_type = PMSI_TNLTYPE_NO_INFO;
		bgp_attr_extra_put(attr);
	} else if (old == PMSI_TNLTYPE_NO_INFO)
		bgp_attr_extra_get(attr)->pmsi_tnl_type = pmsi_tnl_type;
	else
		attr->extra->pmsi_tnl_type = pmsi_tnl_type;
}

static inline const struct in6_addr *bgp_attr_get_tunn_id(const struct attr *attr)
{
	return attr->extra ? &attr->extra->tunn_id : &in6addr_any;
}

static inline void bgp_attr_set_tunn_id(struct attr *attr, const struct in6_addr *tunn_id)
{
	/* Caller must set pmsi_tnl_type to PMSI_TNLTYPE_INGR_REPL first;
	 * that transition is what claims the tunn_id slot.
	 */
	if (!attr->extra || bgp_attr_get_pmsi_tnl_type(attr) != PMSI_TNLTYPE_INGR_REPL)
		return;

	attr->extra->tunn_id = tunn_id ? *tunn_id : in6addr_any;
}

static inline uint64_t bgp_attr_get_partial_attrs(const struct attr *attr)
{
	return attr->extra ? attr->extra->partial_attrs : 0;
}

static inline void bgp_attr_set_partial_attrs(struct attr *attr, uint64_t partial_attrs)
{
	uint64_t old = bgp_attr_get_partial_attrs(attr);

	if (partial_attrs && !old) {
		bgp_attr_extra_get(attr)->partial_attrs = partial_attrs;
	} else if (partial_attrs && old) {
		attr->extra->partial_attrs = partial_attrs; /* replace; refcnt unchanged */
	} else if (!partial_attrs && old) {
		attr->extra->partial_attrs = 0;
		bgp_attr_extra_put(attr);
	}
}

static inline struct ecommunity *
bgp_attr_get_ecommunity(const struct attr *attr)
{
	return attr->ecommunity;
}

static inline void bgp_attr_set_ecommunity(struct attr *attr,
					   struct ecommunity *ecomm)
{
	attr->ecommunity = ecomm;

	if (ecomm && ecomm->size)
		bgp_attr_set(attr, BGP_ATTR_EXT_COMMUNITIES);
	else {
		bgp_attr_unset(attr, BGP_ATTR_EXT_COMMUNITIES);
		bgp_attr_set_partial_attrs(attr, bgp_attr_get_partial_attrs(attr) &
							 ~(1ULL << (BGP_ATTR_EXT_COMMUNITIES - 1)));
	}
}

static inline struct lcommunity *
bgp_attr_get_lcommunity(const struct attr *attr)
{
	return attr->lcommunity;
}

static inline void bgp_attr_set_lcommunity(struct attr *attr,
					   struct lcommunity *lcomm)
{
	attr->lcommunity = lcomm;

	if (lcomm)
		bgp_attr_set(attr, BGP_ATTR_LARGE_COMMUNITIES);
	else {
		bgp_attr_unset(attr, BGP_ATTR_LARGE_COMMUNITIES);
		bgp_attr_set_partial_attrs(attr,
					   bgp_attr_get_partial_attrs(attr) &
						   ~(1ULL << (BGP_ATTR_LARGE_COMMUNITIES - 1)));
	}
}

static inline struct community *bgp_attr_get_community(const struct attr *attr)
{
	return attr->community;
}

static inline void bgp_attr_set_community(struct attr *attr,
					  struct community *comm)
{
	attr->community = comm;

	if (comm)
		bgp_attr_set(attr, BGP_ATTR_COMMUNITIES);
	else {
		bgp_attr_unset(attr, BGP_ATTR_COMMUNITIES);
		bgp_attr_set_partial_attrs(attr, bgp_attr_get_partial_attrs(attr) &
							 ~(1ULL << (BGP_ATTR_COMMUNITIES - 1)));
	}
}

static inline struct ecommunity *
bgp_attr_get_ipv6_ecommunity(const struct attr *attr)
{
	return attr->extra ? attr->extra->ipv6_ecommunity : NULL;
}

static inline void bgp_attr_set_ipv6_ecommunity(struct attr *attr,
						struct ecommunity *ipv6_ecomm)
{
	struct ecommunity *old = bgp_attr_get_ipv6_ecommunity(attr);

	if (ipv6_ecomm && !old) {
		bgp_attr_extra_get(attr)->ipv6_ecommunity = ipv6_ecomm;
	} else if (ipv6_ecomm && old) {
		attr->extra->ipv6_ecommunity = ipv6_ecomm; /* replace; refcnt unchanged */
	} else if (!ipv6_ecomm && old) {
		attr->extra->ipv6_ecommunity = NULL;
		bgp_attr_extra_put(attr);
	}

	if (ipv6_ecomm && ipv6_ecomm->size)
		bgp_attr_set(attr, BGP_ATTR_IPV6_EXT_COMMUNITIES);
	else {
		bgp_attr_unset(attr, BGP_ATTR_IPV6_EXT_COMMUNITIES);
		bgp_attr_set_partial_attrs(attr,
					   bgp_attr_get_partial_attrs(attr) &
						   ~(1ULL << (BGP_ATTR_IPV6_EXT_COMMUNITIES - 1)));
	}
}

static inline struct transit *bgp_attr_get_transit(const struct attr *attr)
{
	return attr->transit;
}

static inline void bgp_attr_set_transit(struct attr *attr,
					struct transit *transit)
{
	attr->transit = transit;
}

static inline struct bgp_nhc *bgp_attr_get_nhc(const struct attr *attr)
{
	return attr->extra ? attr->extra->nhc : NULL;
}

static inline void bgp_attr_set_nhc(struct attr *attr, struct bgp_nhc *bnc)
{
	struct bgp_nhc *old = bgp_attr_get_nhc(attr);

	if (bnc && !old) {
		bgp_attr_extra_get(attr)->nhc = bnc;
	} else if (bnc && old) {
		attr->extra->nhc = bnc; /* replace; refcnt unchanged */
	} else if (!bnc && old) {
		attr->extra->nhc = NULL;
		bgp_attr_extra_put(attr);
	}

	if (bnc)
		bgp_attr_set(attr, BGP_ATTR_NHC);
	else
		bgp_attr_unset(attr, BGP_ATTR_NHC);
}

/* draft-uttaro-idr-bgp-oad says AIGP must be disabled to be sent
 * over OAD session, we need explicitly enable AIGP for OAD session.
 */
#define AIGP_TRANSMIT_ALLOWED(peer)                                                               \
	(CHECK_FLAG((peer)->flags, PEER_FLAG_AIGP) || ((peer)->sort != BGP_PEER_EBGP))

static inline struct bgp_aigp_tlvs *bgp_attr_get_aigp_tlvs(const struct attr *attr)
{
	return attr->extra ? attr->extra->aigp_tlvs : NULL;
}

static inline void bgp_attr_set_aigp_tlvs(struct attr *attr, struct bgp_aigp_tlvs *tlvs)
{
	struct bgp_aigp_tlvs *old = bgp_attr_get_aigp_tlvs(attr);

	if (tlvs && !old) {
		bgp_attr_extra_get(attr)->aigp_tlvs = tlvs;
	} else if (tlvs && old) {
		attr->extra->aigp_tlvs = tlvs; /* replace; refcnt unchanged */
	} else if (!tlvs && old) {
		attr->extra->aigp_tlvs = NULL;
		bgp_attr_extra_put(attr);
	}

	if (tlvs)
		bgp_attr_set(attr, BGP_ATTR_AIGP);
	else
		bgp_attr_unset(attr, BGP_ATTR_AIGP);
}

static inline uint64_t bgp_attr_get_aigp_metric(const struct attr *attr)
{
	struct bgp_aigp_tlvs *tlvs = bgp_attr_get_aigp_tlvs(attr);

	return tlvs ? tlvs->metric[0] : 0;
}

extern void bgp_attr_set_aigp_metric(struct attr *attr, uint64_t aigp);
extern void bgp_attr_unset_aigp_metric(struct attr *attr);

static inline uint64_t bgp_aigp_metric_add(uint64_t aigp, uint64_t value)
{
	return aigp > UINT64_MAX - value ? UINT64_MAX : aigp + value;
}

static inline uint64_t bgp_aigp_metric_total(struct bgp_path_info *bpi, const struct attr *attr)
{
	uint64_t aigp = bgp_attr_get_aigp_metric(attr);

	/* Don't increment if it's locally sourced */
	if (bpi->peer == bpi->peer->bgp->peer_self)
		return aigp;

	return bpi->extra ? bgp_aigp_metric_add(aigp, bpi->extra->igpmetric) : aigp;
}

static inline void bgp_attr_set_med(struct attr *attr, uint32_t med)
{
	attr->med = med;
	bgp_attr_set(attr, BGP_ATTR_MULTI_EXIT_DISC);
}

static inline struct cluster_list *bgp_attr_get_cluster(const struct attr *attr)
{
	return attr->cluster1;
}

static inline void bgp_attr_set_cluster(struct attr *attr,
					struct cluster_list *cl)
{
	attr->cluster1 = cl;

	if (cl)
		bgp_attr_set(attr, BGP_ATTR_CLUSTER_LIST);
	else
		bgp_attr_unset(attr, BGP_ATTR_CLUSTER_LIST);
}

static inline struct in_addr bgp_attr_get_originator_id(const struct attr *attr)
{
	return attr->originator_id;
}

static inline void bgp_attr_set_originator_id(struct attr *attr, struct in_addr originator_id)
{
	attr->originator_id = originator_id;

	if (originator_id.s_addr != INADDR_ANY)
		bgp_attr_set(attr, BGP_ATTR_ORIGINATOR_ID);
	else
		bgp_attr_unset(attr, BGP_ATTR_ORIGINATOR_ID);
}

static inline uint8_t bgp_attr_get_es_flags(const struct attr *attr)
{
	return attr->extra ? attr->extra->es_flags : 0;
}

static inline void bgp_attr_set_es_flags(struct attr *attr, uint8_t es_flags)
{
	uint8_t old = bgp_attr_get_es_flags(attr);

	if (es_flags && !old)
		bgp_attr_extra_get(attr)->es_flags = es_flags;
	else if (es_flags && old)
		attr->extra->es_flags = es_flags; /* replace; refcnt unchanged */
	else if (!es_flags && old) {
		attr->extra->es_flags = 0;
		bgp_attr_extra_put(attr);
	}
}

static inline uint8_t bgp_attr_get_df_alg(const struct attr *attr)
{
	return attr->extra ? attr->extra->df_alg : 0;
}

static inline void bgp_attr_set_df_alg(struct attr *attr, uint8_t df_alg)
{
	uint8_t old = bgp_attr_get_df_alg(attr);

	if (df_alg && !old)
		bgp_attr_extra_get(attr)->df_alg = df_alg;
	else if (df_alg && old)
		attr->extra->df_alg = df_alg; /* replace; refcnt unchanged */
	else if (!df_alg && old) {
		attr->extra->df_alg = 0;
		bgp_attr_extra_put(attr);
	}
}

static inline uint8_t bgp_attr_get_evpn_flags(const struct attr *attr)
{
	return attr->extra ? attr->extra->evpn_flags : 0;
}

static inline void bgp_attr_set_evpn_flags(struct attr *attr, uint8_t evpn_flags)
{
	uint8_t old = bgp_attr_get_evpn_flags(attr);

	if (evpn_flags && !old)
		bgp_attr_extra_get(attr)->evpn_flags = evpn_flags;
	else if (evpn_flags && old)
		attr->extra->evpn_flags = evpn_flags; /* replace; refcnt unchanged */
	else if (!evpn_flags && old) {
		attr->extra->evpn_flags = 0;
		bgp_attr_extra_put(attr);
	}
}

static inline uint16_t bgp_attr_get_df_pref(const struct attr *attr)
{
	return attr->extra ? attr->extra->df_pref : 0;
}

static inline void bgp_attr_set_df_pref(struct attr *attr, uint16_t df_pref)
{
	uint16_t old = bgp_attr_get_df_pref(attr);

	if (df_pref && !old)
		bgp_attr_extra_get(attr)->df_pref = df_pref;
	else if (df_pref && old)
		attr->extra->df_pref = df_pref; /* replace; refcnt unchanged */
	else if (!df_pref && old) {
		attr->extra->df_pref = 0;
		bgp_attr_extra_put(attr);
	}
}

static inline uint32_t bgp_attr_get_mm_seqnum(const struct attr *attr)
{
	return attr->extra ? attr->extra->mm_seqnum : 0;
}

static inline void bgp_attr_set_mm_seqnum(struct attr *attr, uint32_t mm_seqnum)
{
	uint32_t old = bgp_attr_get_mm_seqnum(attr);

	if (mm_seqnum && !old)
		bgp_attr_extra_get(attr)->mm_seqnum = mm_seqnum;
	else if (mm_seqnum && old)
		attr->extra->mm_seqnum = mm_seqnum; /* replace; refcnt unchanged */
	else if (!mm_seqnum && old) {
		attr->extra->mm_seqnum = 0;
		bgp_attr_extra_put(attr);
	}
}

static inline uint32_t bgp_attr_get_mm_sync_seqnum(const struct attr *attr)
{
	return attr->extra ? attr->extra->mm_sync_seqnum : 0;
}

static inline void bgp_attr_set_mm_sync_seqnum(struct attr *attr, uint32_t mm_sync_seqnum)
{
	uint32_t old = bgp_attr_get_mm_sync_seqnum(attr);

	if (mm_sync_seqnum && !old)
		bgp_attr_extra_get(attr)->mm_sync_seqnum = mm_sync_seqnum;
	else if (mm_sync_seqnum && old)
		attr->extra->mm_sync_seqnum = mm_sync_seqnum; /* replace; refcnt unchanged */
	else if (!mm_sync_seqnum && old) {
		attr->extra->mm_sync_seqnum = 0;
		bgp_attr_extra_put(attr);
	}
}

static inline const struct ethaddr *bgp_attr_get_rmac(const struct attr *attr)
{
	static const struct ethaddr zero_rmac;

	return attr->extra ? &attr->extra->rmac : &zero_rmac;
}

static inline void bgp_attr_set_rmac(struct attr *attr, const struct ethaddr *rmac)
{
	bool new_set = rmac && !is_zero_mac(rmac);
	bool old_set = !is_zero_mac(bgp_attr_get_rmac(attr));

	if (new_set && !old_set)
		bgp_attr_extra_get(attr)->rmac = *rmac;
	else if (new_set && old_set)
		attr->extra->rmac = *rmac; /* replace; refcnt unchanged */
	else if (!new_set && old_set) {
		attr->extra->rmac = (struct ethaddr){};
		bgp_attr_extra_put(attr);
	}
}

static inline const esi_t *bgp_attr_get_esi(const struct attr *attr)
{
	static const esi_t zero_esi;

	return attr->extra ? &attr->extra->esi : &zero_esi;
}

static inline void bgp_attr_set_esi(struct attr *attr, const esi_t *esi)
{
	static const esi_t zero_esi;
	bool new_set = esi && memcmp(esi, &zero_esi, sizeof(zero_esi));
	bool old_set = memcmp(bgp_attr_get_esi(attr), &zero_esi, sizeof(zero_esi));

	if (new_set && !old_set)
		bgp_attr_extra_get(attr)->esi = *esi;
	else if (new_set && old_set)
		attr->extra->esi = *esi; /* replace; refcnt unchanged */
	else if (!new_set && old_set) {
		attr->extra->esi = (esi_t){};
		bgp_attr_extra_put(attr);
	}
}

static inline struct bgp_route_evpn *
bgp_attr_get_evpn_overlay(const struct attr *attr)
{
	return attr->extra ? attr->extra->evpn_overlay : NULL;
}

static inline void bgp_attr_set_evpn_overlay(struct attr *attr,
					     struct bgp_route_evpn *bre)
{
	struct bgp_route_evpn *old = bgp_attr_get_evpn_overlay(attr);

	if (bre && !old) {
		bgp_attr_extra_get(attr)->evpn_overlay = bre;
	} else if (bre && old) {
		attr->extra->evpn_overlay = bre; /* replace; refcnt unchanged */
	} else if (!bre && old) {
		attr->extra->evpn_overlay = NULL;
		bgp_attr_extra_put(attr);
	}
}

static inline struct bgp_ls_attr *bgp_attr_get_ls_attr(const struct attr *attr)
{
	return attr->extra ? attr->extra->ls_attr : NULL;
}

static inline void bgp_attr_set_ls_attr(struct attr *attr, struct bgp_ls_attr *ls_attr)
{
	struct bgp_ls_attr *old = bgp_attr_get_ls_attr(attr);

	if (ls_attr && !old) {
		bgp_attr_extra_get(attr)->ls_attr = ls_attr;
	} else if (ls_attr && old) {
		attr->extra->ls_attr = ls_attr; /* replace; refcnt unchanged */
	} else if (!ls_attr && old) {
		attr->extra->ls_attr = NULL;
		bgp_attr_extra_put(attr);
	}

	if (ls_attr)
		bgp_attr_set(attr, BGP_ATTR_LINK_STATE);
	else
		bgp_attr_unset(attr, BGP_ATTR_LINK_STATE);
}

static inline uint32_t bgp_attr_get_otc(const struct attr *attr)
{
	return attr->extra ? attr->extra->otc : 0;
}

static inline void bgp_attr_set_otc(struct attr *attr, uint32_t otc)
{
	uint32_t old = bgp_attr_get_otc(attr);

	if (otc && !old) {
		bgp_attr_extra_get(attr)->otc = otc;
		bgp_attr_set(attr, BGP_ATTR_OTC);
	} else if (otc && old) {
		attr->extra->otc = otc; /* replace; refcnt unchanged */
		bgp_attr_set(attr, BGP_ATTR_OTC);
	} else if (!otc && old) {
		attr->extra->otc = 0;
		bgp_attr_extra_put(attr);
		bgp_attr_unset(attr, BGP_ATTR_OTC);
	}
}

static inline uint8_t bgp_attr_partial(const struct attr *attr, uint8_t type)
{
	if (type < 1 || type > 64)
		return 0;

	return CHECK_FLAG(bgp_attr_get_partial_attrs(attr), 1ULL << (type - 1))
		       ? BGP_ATTR_FLAG_PARTIAL
		       : 0;
}

static inline struct bgp_attr_srv6_vpn *bgp_attr_get_srv6_vpn(const struct attr *attr)
{
	return attr->extra ? attr->extra->srv6_vpn : NULL;
}

static inline void bgp_attr_set_srv6_vpn(struct attr *attr, struct bgp_attr_srv6_vpn *vpn)
{
	struct bgp_attr_srv6_vpn *old = bgp_attr_get_srv6_vpn(attr);

	if (vpn && !old) {
		bgp_attr_extra_get(attr)->srv6_vpn = vpn;
	} else if (vpn && old) {
		attr->extra->srv6_vpn = vpn; /* replace; refcnt unchanged */
	} else if (!vpn && old) {
		attr->extra->srv6_vpn = NULL;
		bgp_attr_extra_put(attr);
	}
}

static inline struct bgp_attr_srv6_service *bgp_attr_get_srv6_l3service(const struct attr *attr)
{
	return attr->extra ? attr->extra->srv6_l3service : NULL;
}

static inline struct bgp_attr_srv6_service *bgp_attr_get_srv6_l2service(const struct attr *attr)
{
	return attr->extra ? attr->extra->srv6_l2service : NULL;
}

static inline void bgp_attr_set_srv6_l3service(struct attr *attr,
					       struct bgp_attr_srv6_service *srv6_l3service)
{
	struct bgp_attr_srv6_service *old = bgp_attr_get_srv6_l3service(attr);

	if (srv6_l3service && !old) {
		bgp_attr_extra_get(attr)->srv6_l3service = srv6_l3service;
	} else if (srv6_l3service && old) {
		attr->extra->srv6_l3service = srv6_l3service; /* replace; refcnt unchanged */
	} else if (!srv6_l3service && old) {
		attr->extra->srv6_l3service = NULL;
		bgp_attr_extra_put(attr);
	}
}

static inline void bgp_attr_set_srv6_l2service(struct attr *attr,
					       struct bgp_attr_srv6_service *srv6_l2service)
{
	struct bgp_attr_srv6_service *old = bgp_attr_get_srv6_l2service(attr);

	if (srv6_l2service && !old) {
		bgp_attr_extra_get(attr)->srv6_l2service = srv6_l2service;
	} else if (srv6_l2service && old) {
		attr->extra->srv6_l2service = srv6_l2service; /* replace; refcnt unchanged */
	} else if (!srv6_l2service && old) {
		attr->extra->srv6_l2service = NULL;
		bgp_attr_extra_put(attr);
	}
}

static inline struct bgp_attr_encap_subtlv *
bgp_attr_get_vnc_subtlvs(const struct attr *attr)
{
#ifdef ENABLE_BGP_VNC
	return attr->vnc_subtlvs;
#else
	return NULL;
#endif
}

static inline void
bgp_attr_set_vnc_subtlvs(struct attr *attr,
			 struct bgp_attr_encap_subtlv *vnc_subtlvs)
{
#ifdef ENABLE_BGP_VNC
	attr->vnc_subtlvs = vnc_subtlvs;
#endif
}

extern bool route_matches_soo(struct bgp_path_info *pi, struct ecommunity *soo);
extern void evpn_overlay_free(struct bgp_route_evpn *bre);
extern struct bgp_route_evpn *evpn_overlay_intern(struct bgp_route_evpn *bre);

extern int bgp_attr_stream_put_labeled_prefix(struct stream *s, const struct prefix *p,
					      mpls_label_t *labels, uint8_t num_labels,
					      bool addpath_capable, uint32_t addpath_tx_id);

static inline int bgp_attr_stream_put_prefix_addpath(struct stream *s, const struct prefix *p,
						     bool addpath_capable, uint32_t addpath_tx_id)
{
	return bgp_attr_stream_put_labeled_prefix(s, p, NULL, 0, addpath_capable, addpath_tx_id);
}

#endif /* _QUAGGA_BGP_ATTR_H */
